/* tslint:disable */
require("./App.module.css");
const styles = {
  app: 'app_133c042c',
  teams: 'teams_133c042c',
  welcome: 'welcome_133c042c',
  welcomeImage: 'welcomeImage_133c042c',
  links: 'links_133c042c'
};

export default styles;
/* tslint:enable */