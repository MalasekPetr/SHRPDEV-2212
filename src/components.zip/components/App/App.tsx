import * as React from 'react';
import styles from './App.module.scss';
import { IAppProps } from './IAppProps';
import { escape } from '@microsoft/sp-lodash-subset';
import { Row } from '../../components';

export class App extends React.Component<IAppProps, {}> {
  public render(): React.ReactElement<IAppProps> {
    const {
      description,
      isDarkTheme,
      environmentMessage,
      hasTeamsContext,
      userDisplayName
    } = this.props;
    
this.componentDidMount



    return (
      <section className={`${styles.app} ${hasTeamsContext ? styles.teams : ''}`}>
        <div>
          <Row Title='pokus' />
        </div>
      </section>
    );
  }
}
