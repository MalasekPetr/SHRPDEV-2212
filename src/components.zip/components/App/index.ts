export { App } from './App';
export { IAppProps } from './IAppProps';
export * from './App.module.scss';
