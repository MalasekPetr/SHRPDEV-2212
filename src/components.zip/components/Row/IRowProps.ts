export interface IRowProps {
    Title: string;
    Number?: Number;
    Date?: Date;
    Editor?: string;
}