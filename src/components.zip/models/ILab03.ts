export interface ILab03 {
    Id?:                       number;
    Title?:                    string;
    Modified?:                 Date;
    Created?:                  Date;
    AuthorID?:                 number;
    EditorID?:                 number;
    Number?:                   number;
    Date?:                     Date;
}